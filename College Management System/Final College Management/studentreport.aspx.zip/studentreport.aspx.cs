using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Windows.Forms;
public partial class studentreport : System.Web.UI.Page
{
    connect c;
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void btnback_Click(object sender, EventArgs e)
    {
        Response.Redirect("faculty.aspx");
    }
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        try
        {
            c = new connect();
            c.cmd.CommandText = "insert into stdreport values(@name,@rollno,@course,@sem,@subject1,@m1,@class1held,@class1attend,@subject2,@m2,@class2held,@class2attend,@subject3,@m3,@class3held,@class3attend,@subject4,@m4,@class4held,@class4attend,@subject5,@m5,@class5held,@class5attend,@subject6,@m6,@class6held,@class6attend,@totalclassheld,@totalclass,@attnpercentage,@totalmarks,@avg,@grade,@remarks)";
            c.cmd.Parameters.Add("@name", SqlDbType.NVarChar).Value = txtsname.Text;
            c.cmd.Parameters.Add("@rollno", SqlDbType.SmallInt).Value = Convert.ToInt16(txtsrollno.Text);
            c.cmd.Parameters.Add("@course", SqlDbType.NVarChar).Value = ddlscourse.SelectedItem.Text;
            c.cmd.Parameters.Add("@sem", SqlDbType.SmallInt).Value = Convert.ToInt16(txtsem.Text);
            c.cmd.Parameters.Add("@subject1", SqlDbType.NVarChar).Value = txtsub1.Text;
            c.cmd.Parameters.Add("@m1", SqlDbType.SmallInt).Value = Convert.ToInt16(txtm1.Text);
            c.cmd.Parameters.Add("@class1held", SqlDbType.SmallInt).Value = Convert.ToInt16(txtclass1held.Text);
            c.cmd.Parameters.Add("@class1attend", SqlDbType.SmallInt).Value = Convert.ToInt16(txtclass1attend.Text);
            c.cmd.Parameters.Add("@subject2", SqlDbType.NVarChar).Value = txtsub2.Text;
            c.cmd.Parameters.Add("@m2", SqlDbType.SmallInt).Value = Convert.ToInt16(txtm2.Text);
            c.cmd.Parameters.Add("@class2held", SqlDbType.SmallInt).Value = Convert.ToInt16(txtclass2held.Text);
            c.cmd.Parameters.Add("@class2attend", SqlDbType.SmallInt).Value = Convert.ToInt16(txtclass3attend.Text);
            c.cmd.Parameters.Add("@subject3", SqlDbType.NVarChar).Value = txtsub3.Text;
            c.cmd.Parameters.Add("@m3", SqlDbType.SmallInt).Value = Convert.ToInt16(txtm3.Text);
            c.cmd.Parameters.Add("@class3held", SqlDbType.SmallInt).Value = Convert.ToInt16(txtclass3held.Text);
            c.cmd.Parameters.Add("@class3attend", SqlDbType.SmallInt).Value = Convert.ToInt16(txtclass3attend.Text);
            c.cmd.Parameters.Add("@subject4", SqlDbType.NVarChar).Value = txtsub4.Text;
            c.cmd.Parameters.Add("@m4", SqlDbType.SmallInt).Value = Convert.ToInt16(txtm4.Text);
            c.cmd.Parameters.Add("@class4held", SqlDbType.SmallInt).Value = Convert.ToInt16(txtclass4held.Text);
            c.cmd.Parameters.Add("@class4attend", SqlDbType.SmallInt).Value = Convert.ToInt16(txtclass4attend.Text);
            c.cmd.Parameters.Add("@subject5", SqlDbType.NVarChar).Value = txtsub5.Text;
            c.cmd.Parameters.Add("@m5", SqlDbType.SmallInt).Value = Convert.ToInt16(txtm5.Text);
            c.cmd.Parameters.Add("@class5held", SqlDbType.SmallInt).Value = Convert.ToInt16(txtclass4held.Text);
            c.cmd.Parameters.Add("@class5attend", SqlDbType.SmallInt).Value = Convert.ToInt16(txtclass5attend.Text);
            c.cmd.Parameters.Add("@subject6", SqlDbType.NVarChar).Value = txtsub6.Text;
            c.cmd.Parameters.Add("@m6", SqlDbType.SmallInt).Value = Convert.ToInt16(txtm6.Text);
            c.cmd.Parameters.Add("@class6held", SqlDbType.SmallInt).Value = Convert.ToInt16(txtclass6held.Text);
            c.cmd.Parameters.Add("@class6attend", SqlDbType.SmallInt).Value = Convert.ToInt16(txtclass6attend.Text);
            c.cmd.Parameters.Add("@totalclassheld", SqlDbType.SmallInt).Value = Convert.ToInt16(txttotclasshld.Text);
            c.cmd.Parameters.Add("@totalclass", SqlDbType.SmallInt).Value = Convert.ToInt16(txttotclass.Text);
            c.cmd.Parameters.Add("@attnpercentage", SqlDbType.Decimal).Value = Convert.ToDecimal(txtattperc.Text);
            c.cmd.Parameters.Add("@totalmarks", SqlDbType.SmallInt).Value = Convert.ToInt16(txttotmarks.Text);
            c.cmd.Parameters.Add("@avg", SqlDbType.Decimal).Value = Convert.ToDecimal(txtavg.Text);
            c.cmd.Parameters.Add("@grade", SqlDbType.NVarChar).Value = txtgrade.Text;
            c.cmd.Parameters.Add("@remarks", SqlDbType.NVarChar).Value = txtremarks.Text;
            c.cmd.ExecuteNonQuery();
            MessageBox.Show("Submitted successfully");
        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            c.cnn.Close();
        }

    }
    protected void btnreset_Click(object sender, EventArgs e)
    {
        txtsname.Text = "";
        txtsrollno.Text = "";
        txtsem.Text = "";
        txtsub1.Text = "";
        txtm1.Text = "";
        txtclass1held.Text = "";
        txtclass1attend.Text = "";
        txtsub2.Text = "";
        txtm2.Text = "";
        txtclass2held.Text = "";
        txtclass2attend.Text = "";
        txtsub3.Text = "";
        txtm3.Text = "";
        txtclass3held.Text = "";
        txtclass3attend.Text = "";
        txtsub4.Text = "";
        txtm4.Text = "";
        txtclass4held.Text = "";
        txtclass4attend.Text = "";
        txtsub5.Text = "";
        txtm5.Text = "";
        txtclass5held.Text = "";
        txtclass5attend.Text = "";
        txtsub6.Text = "";
        txtm6.Text = "";
        txtclass6held.Text = "";
        txtclass6attend.Text = "";
        txttotclass.Text = "";
        txtattperc.Text = "";
        txttotmarks.Text = "";
        txtavg.Text = "";
        txtgrade.Text = "";
        txtremarks.Text = "";
    }

    protected void btncalc_Click(object sender, EventArgs e)
    {
        int h1,h2,h3,h4,h5,h6,totalheld=0;
        h1=Convert .ToInt16(txtclass1held .Text );
        h2=Convert .ToInt16 (txtclass2held .Text );
        h3=Convert .ToInt16 (txtclass3held .Text );
        h4=Convert .ToInt16 (txtclass4held .Text);
        h5 =Convert .ToInt16 (txtclass5held .Text);
        h6 =Convert .ToInt16 (txtclass6held .Text );
        totalheld = h1+ h2 + h3 + h4 + h5 + h6;
        int c1, c2, c3, c4, c5, c6, totalatt=0;
        Double avgatt=0.0;
        c1=Convert .ToInt16 (txtclass1attend .Text);
        c2 = Convert.ToInt16(txtclass2attend.Text);
        c3 = Convert.ToInt16(txtclass3attend.Text);
        c4 = Convert.ToInt16(txtclass4attend.Text);
        c5 = Convert.ToInt16(txtclass5attend.Text);
        c6 = Convert.ToInt16(txtclass6attend.Text);
        totalatt = c1+c2 + c3 + c4 + c5 + c6;
        avgatt = ((totalatt/totalheld) * 100);
        avgatt = totalatt/totalheld;
        txttotclasshld.Text = Convert.ToString(totalheld);
        txttotclass.Text = Convert.ToString(totalatt);
        txtattperc.Text = Convert.ToString(avgatt);
        int m1, m2, m3, m4, m5, m6, total;
        double avg;
        String grade;
        m1 = Convert.ToInt16(txtm1.Text);
        m2 = Convert.ToInt16(txtm2.Text);
        m3 = Convert.ToInt16(txtm3.Text);
        m4 = Convert.ToInt16(txtm4.Text);
        m5 = Convert.ToInt16(txtm5.Text);
        m6 = Convert.ToInt16(txtm6.Text);
        total = m1 + m2 + m3 + m4 + m5 + m6;
        avg = total / 6;
        if (m1 < 35 || m2 < 35 || m3 < 35 || m4 < 35 || m5 < 35 || m6 < 35)
        {
            grade = "Fail";
        }
        else if (avg >= 85)
            grade = "Distinction";
        else if (avg >= 70)
            grade = "First class";
        else if (avg >= 60)
            grade = "Second Class";
        else
            grade = "Pass Class";
        txttotmarks.Text=Convert.ToString (total);
        txtavg.Text = Convert.ToString(avg);
        txtgrade.Text = grade;

    }

    protected void btndelete_Click(object sender, EventArgs e)
    {
        Response.Redirect("deletesreport.aspx");
    }
    protected void btndisplay_Click(object sender, EventArgs e)
    {
        Response.Redirect("studentdisplay1.aspx");
    }
}
